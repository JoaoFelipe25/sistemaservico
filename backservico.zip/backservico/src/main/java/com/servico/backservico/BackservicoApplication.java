package com.servico.backservico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackservicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackservicoApplication.class, args);
	}

}
